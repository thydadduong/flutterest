import 'package:flutter/material.dart';

class FragmentItem {
  String title;
  IconData icon;
  FragmentItem(this.title, this.icon);
}
